let mahasiswa = {
    nama: "Sandhika Galih",
    nrp: "043040023",
    email: "sandhikagalih@unpas.ac.id"

}

console.log(JSON.stringify(mahasiswa));